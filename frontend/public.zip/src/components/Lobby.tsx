'use client';

import { useState } from 'react';
import { getSocket } from '@/lib/socket';
import type { GameState } from '@/types/game';

interface LobbyProps {
    gameState: GameState;
    roomCode: string;
}

export default function Lobby({ gameState, roomCode }: LobbyProps) {
    const [copied, setCopied] = useState(false);
    const socket = getSocket();

    // Check if this user is the host via socket ID match from game state
    const currentPlayer = gameState.players.find(p => p.id === socket.id);
    const isHost = currentPlayer?.is_host || false;
    const canStart = gameState.player_count >= 4;

    const handleCopyCode = () => {
        // Check if clipboard API is available (client-side only)
        if (typeof navigator !== 'undefined' && navigator.clipboard) {
            navigator.clipboard.writeText(roomCode);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        }
    };

    const handleStartGame = () => {
        socket.emit('start_game', { room_code: roomCode });
    };

    return (
        <div className="space-y-[2px] animate-fade-in">
            {/* Title */}
            <div className="text-center">
                <h1 className="text-5xl font-bold gradient-text mb-2">Lobby</h1>
            </div>

            {/* Room Code Card */}
            <div className="card-strong text-center space-y-3">
                <p className="text-gray-600">Room Code</p>
                <div className="flex items-center justify-center gap-3">
                    <span className="text-4xl font-bold tracking-widest text-purple-600">
                        {roomCode}
                    </span>
                    <button
                        onClick={handleCopyCode}
                        className="btn btn-secondary text-sm px-4 py-2"
                    >
                        {copied ? '✅ Copied!' : '📋 Copy'}
                    </button>
                </div>
                <p className="text-sm text-gray-500">
                    Share this code with your friends to join
                </p>
            </div>

            {/* Players List */}
            <div className="card">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2 text-gray-800">
                    👥 Players ({gameState.player_count})
                </h2>
                <div className="space-y-2">
                    {gameState.players.map((player, index) => (
                        <div
                            key={player.id}
                            className="player-item animate-slide-in hover:bg-gray-50"
                            style={{ animationDelay: `${index * 0.1}s` }}
                        >
                            <span className="flex items-center gap-2 text-gray-700">
                                <span className="text-2xl">
                                    {player.is_host ? '👑' : '🎮'}
                                </span>
                                <span className="font-medium">{player.name}</span>
                            </span>
                            <span className="text-green-600 text-sm font-medium">● Online</span>
                        </div>
                    ))}
                </div>
            </div>

            {/* Game Info */}
            <div className="card">
                <h3 className="font-semibold text-purple-600 mb-3">Game Rules</h3>
                <ul className="text-sm text-gray-600 space-y-2">
                    <li>🟢 <strong className="text-gray-800">Civilians:</strong> Have the same word. Find and eliminate enemies!</li>
                    <li>🟡 <strong className="text-gray-800">Undercover:</strong> Have a similar word. Blend in and survive!</li>
                    <li>🔴 <strong className="text-gray-800">Mr. White:</strong> Have NO word. Guess the civilian word if eliminated to win!</li>
                </ul>
            </div>

            {/* Game Settings (Host Only) */}
            {isHost && (
                <div className="card">
                    <h3 className="font-semibold text-purple-600 mb-3">⚙️ Game Settings</h3>
                    <div className="space-y-3">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                Number of Undercovers: {gameState.undercover_count || 2}
                            </label>
                            <div className="flex gap-2">
                                {[1, 2, 3].map(count => {
                                    const maxUndercovers = gameState.player_count - 2;
                                    const isDisabled = count > maxUndercovers;
                                    return (
                                        <button
                                            key={count}
                                            onClick={() => {
                                                if (!isDisabled) {
                                                    socket.emit('update_settings', {
                                                        room_code: roomCode,
                                                        undercover_count: count
                                                    });
                                                }
                                            }}
                                            disabled={isDisabled}
                                            className={`flex-1 px-4 py-2 rounded-lg font-medium transition-all ${(gameState.undercover_count || 2) === count
                                                ? 'bg-purple-600 text-white shadow-md'
                                                : isDisabled
                                                    ? 'bg-gray-200 text-gray-400 cursor-not-allowed opacity-50'
                                                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200 border border-gray-200'
                                                }`}
                                        >
                                            {count}
                                        </button>
                                    );
                                })}
                            </div>
                            <p className="text-xs text-gray-500 mt-2">
                                {gameState.player_count < 4
                                    ? 'Need at least 4 players'
                                    : `Max ${gameState.player_count - 2} undercovers with ${gameState.player_count} players`}
                            </p>
                        </div>
                    </div>
                </div>
            )}

            {/* Start Button */}
            {isHost && (
                <button
                    onClick={handleStartGame}
                    disabled={!canStart}
                    className={`btn w-full text-lg ${canStart ? 'btn-primary' : 'btn-secondary opacity-50 cursor-not-allowed'
                        }`}
                >
                    {canStart ? '🚀 Start Game' : `⏳ Need ${4 - gameState.player_count} more player(s)`}
                </button>
            )}

            {!isHost && (
                <div className="card-strong text-center">
                    <p className="text-gray-300">Waiting for host to start the game...</p>
                    <div className="animate-pulse-slow text-4xl mt-2">⏳</div>
                </div>
            )}
        </div>
    );
}
