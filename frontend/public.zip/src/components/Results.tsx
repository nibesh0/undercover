'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { getSocket } from '@/lib/socket';
import type { GameState } from '@/types/game';

interface ResultsProps {
    gameState: GameState;
    roomCode: string;
}

export default function Results({ gameState, roomCode }: ResultsProps) {
    const [showConfetti, setShowConfetti] = useState(false);
    const [allPlayers, setAllPlayers] = useState<any[]>([]);
    const socket = getSocket();
    const router = useRouter();

    useEffect(() => {
        setShowConfetti(true);

        // Listen for revealed player data
        socket.on('game_ended', (data) => {
            if (data.all_players) {
                setAllPlayers(data.all_players);
            }
        });
    }, [socket]);

    const handlePlayAgain = () => {
        socket.emit('play_again', { room_code: roomCode });
    };

    const handleLeave = () => {
        socket.emit('leave_room', { room_code: roomCode });
        router.push('/');
    };

    const getWinnerMessage = () => {
        if (gameState.winner === 'civilians') {
            return {
                title: '🟢 Civilians Win!',
                message: 'All enemies have been eliminated!',
                color: 'text-green-400',
            };
        }
        if (gameState.winner === 'undercovers') {
            return {
                title: '🟡 Undercovers Win!',
                message: 'The infiltrators have prevailed!',
                color: 'text-yellow-400',
            };
        }
        if (gameState.winner === 'mrwhite') {
            return {
                title: '🔴 Mr. White Wins!',
                message: 'Guessed the civilian word correctly!',
                color: 'text-red-400',
            };
        }
        return {
            title: '🎮 Game Over',
            message: 'Thanks for playing!',
            color: 'text-purple-400',
        };
    };

    const winnerInfo = getWinnerMessage();

    const getRoleColor = (role: string) => {
        if (role === 'civilian') return 'border-green-500';
        if (role === 'undercover') return 'border-yellow-500';
        return 'border-red-500';
    };

    const getRoleEmoji = (role: string) => {
        if (role === 'civilian') return '🟢';
        if (role === 'undercover') return '🟡';
        return '🔴';
    };

    return (
        <div className="space-y-[2px] animate-fade-in">
            {/* Confetti Effect */}
            {showConfetti && (
                <div className="fixed inset-0 pointer-events-none z-50">
                    {[...Array(50)].map((_, i) => (
                        <div
                            key={i}
                            className="absolute w-2 h-2 bg-purple-500 rounded-full animate-confetti"
                            style={{
                                left: `${Math.random() * 100}%`,
                                top: '-10px',
                                animationDuration: `${2 + Math.random() * 3}s`,
                                animationDelay: `${Math.random() * 2}s`,
                                backgroundColor: ['#8b5cf6', '#06b6d4', '#10b981', '#f59e0b'][
                                    Math.floor(Math.random() * 4)
                                ],
                            }}
                        />
                    ))}
                </div>
            )}

            {/* Winner Announcement */}
            <div className="card-strong text-center space-y-4">
                <div className="text-7xl animate-pulse-slow">🏆</div>
                <h1 className={`text-5xl font-bold ${winnerInfo.color}`}>
                    {winnerInfo.title}
                </h1>
                <p className="text-xl text-gray-600">{winnerInfo.message}</p>
            </div>

            {/* Player Roles Revealed */}
            <div className="card">
                <h2 className="text-2xl font-semibold mb-4 text-center text-gray-800">
                    👥 Roles Revealed
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {(allPlayers.length > 0 ? allPlayers : gameState.players).map((player, index) => (
                        <div
                            key={player.id}
                            className={`glass rounded-lg p-4 border-2 ${getRoleColor(player.role || 'civilian')} bg-gray-50`}
                            style={{ animationDelay: `${index * 0.1}s` }}
                        >
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <span className="text-3xl">{getRoleEmoji(player.role || 'civilian')}</span>
                                    <div>
                                        <p className="font-semibold text-lg text-gray-800">{player.name}</p>
                                        <p className="text-sm text-gray-500 capitalize">
                                            {player.role || 'civilian'}
                                        </p>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <p className="text-lg font-mono text-gray-900 font-bold">
                                        {player.word || 'No word'}
                                    </p>
                                    {!player.is_alive && (
                                        <p className="text-xs text-red-500 font-semibold">Eliminated</p>
                                    )}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <button onClick={handlePlayAgain} className="btn btn-primary text-lg">
                    🔄 Play Again
                </button>
                <button onClick={handleLeave} className="btn btn-secondary text-lg">
                    🚪 Leave Game
                </button>
            </div>
        </div>
    );
}
