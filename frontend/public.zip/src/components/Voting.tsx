'use client';

import { useState } from 'react';
import { getSocket } from '@/lib/socket';
import type { GameState, PlayerData } from '@/types/game';

interface VotingProps {
    gameState: GameState;
    playerData: PlayerData | null;
    roomCode: string;
}

export default function Voting({ gameState, playerData, roomCode }: VotingProps) {
    const [selectedPlayer, setSelectedPlayer] = useState<string | null>(null);
    const [hasVoted, setHasVoted] = useState(false);
    const socket = getSocket();

    const alivePlayers = gameState.players.filter(p => p.is_alive);
    const currentPlayer = gameState.players.find(p => p.id === socket.id);

    const handleVote = () => {
        if (!selectedPlayer) {
            alert('Please select a player to vote for');
            return;
        }

        socket.emit('submit_vote', {
            room_code: roomCode,
            voted_for_id: selectedPlayer,
        });

        setHasVoted(true);
    };

    return (
        <div className="space-y-[2px] animate-fade-in">
            {/* Header */}
            <div className="text-center">
                <h1 className="text-4xl font-bold text-gray-800 mb-2">🗳️ Voting Time</h1>
                <p className="text-gray-600">Who do you think is Undercover or Mr. White?</p>
            </div>

            {/* Voting Grid */}
            {!hasVoted && currentPlayer?.is_alive ? (
                <div className="space-y-4">
                    <div className="card">
                        <h3 className="font-semibold mb-4">Select a player to eliminate:</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {alivePlayers
                                .filter(p => p.id !== socket.id) // Can't vote for yourself
                                .map((player) => (
                                    <button
                                        key={player.id}
                                        onClick={() => setSelectedPlayer(player.id)}
                                        className={`card-strong text-left transition-all ${selectedPlayer === player.id
                                            ? 'ring-2 ring-purple-500 scale-105'
                                            : 'hover:scale-102'
                                            }`}
                                    >
                                        <div className="flex items-center gap-3">
                                            <div className="text-3xl">
                                                {player.is_host ? '👑' : '🎮'}
                                            </div>
                                            <div>
                                                <p className="font-semibold text-lg">{player.name}</p>
                                                {selectedPlayer === player.id && (
                                                    <p className="text-sm text-purple-400">Selected ✓</p>
                                                )}
                                            </div>
                                        </div>
                                    </button>
                                ))}
                        </div>
                    </div>

                    {/* Confirm Button */}
                    <button
                        onClick={handleVote}
                        disabled={!selectedPlayer}
                        className={`btn w-full text-lg ${selectedPlayer ? 'btn-danger' : 'btn-secondary opacity-50 cursor-not-allowed'
                            }`}
                    >
                        {selectedPlayer ? '✅ Confirm Vote' : '⏳ Select a player'}
                    </button>
                </div>
            ) : (
                <div className="card-strong text-center space-y-4">
                    <div className="text-6xl animate-pulse-slow">⏳</div>
                    <h2 className="text-2xl font-semibold">
                        {currentPlayer?.is_alive ? 'Vote submitted!' : 'You are eliminated'}
                    </h2>
                    <p className="text-gray-300">
                        Waiting for other players to vote...
                    </p>
                </div>
            )}

            {/* Recent Clues Reference */}
            <div className="card">
                <h3 className="font-semibold mb-3">📝 Recent Clues</h3>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                    {gameState.clues.slice(-8).map((clue, index) => (
                        <div key={index} className="glass rounded px-3 py-2 text-sm">
                            <strong className="text-purple-300">{clue.player_name}:</strong>{' '}
                            {clue.clue}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
